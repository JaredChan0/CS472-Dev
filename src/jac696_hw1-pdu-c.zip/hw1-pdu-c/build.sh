#!/bin/bash
gcc -g -o decoder decoder.c